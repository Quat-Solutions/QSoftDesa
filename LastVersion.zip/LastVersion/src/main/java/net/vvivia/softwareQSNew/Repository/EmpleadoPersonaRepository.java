package net.vvivia.softwareQSNew.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.vvivia.softwareQSNew.Model.EmpleadoPersona;

public interface EmpleadoPersonaRepository extends JpaRepository<EmpleadoPersona, Integer> {
	
	@Query("Select ep from EmpleadoPersona ep where Nombre like ?1% and Ap_Paterno like ?2% and Ap_Materno like ?3%")
	Page<EmpleadoPersona> buscaFiltroListaEmp(Pageable page, String Nombre, String ApPaterno, String ApMaterno);

}
