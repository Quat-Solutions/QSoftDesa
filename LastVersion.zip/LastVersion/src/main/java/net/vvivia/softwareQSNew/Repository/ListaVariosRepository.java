package net.vvivia.softwareQSNew.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.vvivia.softwareQSNew.Model.ListaVarios;
//nayeli Meza
public interface ListaVariosRepository extends JpaRepository<ListaVarios, Integer>{
		
}
