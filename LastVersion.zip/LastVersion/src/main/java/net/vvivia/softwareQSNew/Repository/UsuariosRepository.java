package net.vvivia.softwareQSNew.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import net.vvivia.softwareQSNew.Model.Usuario;

public interface UsuariosRepository extends JpaRepository<Usuario, Integer> {

}
