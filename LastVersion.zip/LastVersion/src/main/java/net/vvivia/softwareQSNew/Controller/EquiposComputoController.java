package net.vvivia.softwareQSNew.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import net.vvivia.softwareQSNew.Model.EquipoComputo;
import net.vvivia.softwareQSNew.Service.IEquipoComputoService;
import net.vvivia.softwareQSNew.Service.IVariosService;
import net.vvivia.softwareQSNew.Util.Utileria;

@Controller
@RequestMapping("/equiposComputo")
public class EquiposComputoController {

	@Value("${softwareQS.ruta.imagenes}")
	private String ruta;
	
	@Autowired
	private IEquipoComputoService equipoCompService;
	
	@Autowired
	private IVariosService variosService;
	
	@GetMapping("/indexPaginate")
	public String mostrarIndexPaginado(Model model, Pageable page) {
		EquipoComputo eqCompFiltro = new EquipoComputo();
		String marca = "";
		String modelo = "";
		String estatus = "";
		Page<EquipoComputo> listaFiltro = equipoCompService.buscarTodoFiltro(page, marca, modelo, estatus);
		model.addAttribute("equiposComputo", listaFiltro);
		model.addAttribute("eqCompFiltro", eqCompFiltro);
		model.addAttribute("eqComp", equipoCompService.buscarTodo());
		model.addAttribute("marcas", equipoCompService.buscarMarcasEq()); 
		model.addAttribute("modelos", equipoCompService.buscarModelos());
		model.addAttribute("estatus", equipoCompService.buscarEstatus());
		return "equiposComputo/listEquiposComputo";
	}
	
	@GetMapping("/buscaFiltro")
	public String buscaPorFiltro(Model model, Pageable page, EquipoComputo eqCompFiltro ) { //String marca, String modelo, String estatus
		System.out.println("Entro a buscar por filtro: " + eqCompFiltro.getMarca() + " o " + eqCompFiltro.getModelo() + " o " + eqCompFiltro.getEstatus());
		String Marca = eqCompFiltro.getMarca();
		String Modelo = eqCompFiltro.getModelo();
		String Estatus = eqCompFiltro.getEstatus();
		System.out.println("Marca: " + Marca);
		Page<EquipoComputo> lista = equipoCompService.buscarTodoFiltro(page, Marca, Modelo, Estatus);
		model.addAttribute("equiposComputo", lista);
		model.addAttribute("eqCompFiltro", eqCompFiltro);
		model.addAttribute("marcas", equipoCompService.buscarMarcasEq()); 
		model.addAttribute("modelos", equipoCompService.buscarModelos());
		model.addAttribute("estatus", equipoCompService.buscarEstatus());
		System.out.println("Salgo de busqueda filtrada");
		return "equiposComputo/listEquiposComputo";
	}
	
	@GetMapping("/create")
	public String crear (Model model) {
		System.out.println("Entro a Alta Equipo de Computo... ");
		EquipoComputo nuevoEquipo = new EquipoComputo();
		model.addAttribute("eqComp", nuevoEquipo);
		//List<VariosMarca> listVariosMarca = variosMarcaService.buscarTodo();
		model.addAttribute("tipoEqComp", variosService.buscarEquipoComputo());
		model.addAttribute("marcas", variosService.buscarMarcas()); 
		model.addAttribute("memoriaRam", variosService.buscarRam());
		model.addAttribute("procesador", variosService.buscarProcesador());
		model.addAttribute("tipoDD", variosService.buscarTipoDD());
		model.addAttribute("capDD", variosService.buscarCapDD());
		model.addAttribute("SO", variosService.buscarSistemaOperativo());
		model.addAttribute("licOffice", variosService.buscarOffice());
		return "equiposComputo/formEquipoComputo";
	}
	
	@GetMapping("/edit/{id}")
	public String editar(@PathVariable("id") int EquipoComputo_id, Model model)  {
		System.out.println("Entro a editar EquipoComputo... " + EquipoComputo_id);
		EquipoComputo nuevoEquipo = equipoCompService.buscarPorId(EquipoComputo_id);
		model.addAttribute("tipoEqComp", variosService.buscarEquipoComputo());
		model.addAttribute("marcas", variosService.buscarMarcas()); 
		model.addAttribute("memoriaRam", variosService.buscarRam());
		model.addAttribute("procesador", variosService.buscarProcesador());
		model.addAttribute("tipoDD", variosService.buscarTipoDD());
		model.addAttribute("capDD", variosService.buscarCapDD());
		model.addAttribute("SO", variosService.buscarSistemaOperativo());
		model.addAttribute("licOffice", variosService.buscarOffice());
		model.addAttribute("eqComp", nuevoEquipo);
		
		System.out.println("Salgo de editar EquipoComputo... " + nuevoEquipo);
		
		return "equiposComputo/formEquipoComputo";
	}
	
	@PostMapping("/save")
	public String guardar (EquipoComputo eqComp, BindingResult result, RedirectAttributes attributes,  @RequestParam("archivoImagen") MultipartFile multiPart) {
		
		if (result.hasErrors()) {
			for (ObjectError error: result.getAllErrors()){
				System.out.println("Ocurrio un error: "+ error.getDefaultMessage());
			}			
			return "equiposComputo/formEquipoComputo";
		}
		
		if (!multiPart.isEmpty()) {
			//String ruta = "/empleos/img-vacantes/"; // Linux/MAC
			//String ruta = "c:/empleos/img-vacantes/"; // Windows
			String nombreImagen = Utileria.guardarArchivo(multiPart, ruta);
			if (nombreImagen != null){ // La imagen si se subio
				// Procesamos la variable nombreImagen
				eqComp.setFoto(nombreImagen);
			}
		}
		if(eqComp.getEstatus() == null) {
			eqComp.setEstatus("ACTIVO");
		}
		System.out.println("Antes de guardar EquipoComputo: " + eqComp);
		equipoCompService.guardar(eqComp);
		
		attributes.addFlashAttribute("msg", "Registro Guardado");
		System.out.println("Equipo de Computo guardado correctamente... ");
		return "redirect:/equiposComputo/indexPaginate";
	}
	
	@GetMapping("/delete/{id}")
	public String eliminar(@PathVariable("id") int EquipoComputo_id, RedirectAttributes attributes) {
		System.out.println("Borrando equipo de computo con id: " + EquipoComputo_id);
		EquipoComputo eqComp = equipoCompService.buscarPorId(EquipoComputo_id);
		eqComp.setEstatus("INACTIVO");
		equipoCompService.guardar(eqComp);
		attributes.addFlashAttribute("msg","El registro del equipo fue eliminado!");
		return "redirect:/equiposComputo/indexPaginate";
	}
}
