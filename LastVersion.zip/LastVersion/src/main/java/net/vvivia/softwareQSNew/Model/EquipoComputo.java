package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="equipo_computo")
//@Subselect("select equipocomputo_id, tipo, fch_alta, marca, modelo, serie, ram, procesador, dd_serie, dd_tipo, dd_capacidad, cargador_serie, so, office, nombre, foto, observaciones, estatus from equipo_computo where estatus = 'ACTIVA' order by equipocomputo_id")
public class EquipoComputo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer EquipoComputo_id;
	private String Tipo;
	private String Fch_Alta;
	private String Marca;
	private String Modelo;
	private String Serie;
	private String RAM;
	private String Procesador;
	private String DD_Serie;
	private String DD_Tipo;
	private String DD_Capacidad;
	private String Cargador_Serie;
	private String SO;
	private String Office;
	private String Nombre;
	private String Foto;
	private String Observaciones;
	private String Estatus;
	
	public Integer getEquipoComputo_id() {
		return EquipoComputo_id;
	}
	public void setEquipoComputo_id(Integer equipoComputo_id) {
		EquipoComputo_id = equipoComputo_id;
	}
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	public String getFch_Alta() {
		return Fch_Alta;
	}
	public void setFch_Alta(String fch_Alta) {
		Fch_Alta = fch_Alta;
	}
	public String getMarca() {
		return Marca;
	}
	public void setMarca(String marca) {
		Marca = marca;
	}
	public String getModelo() {
		return Modelo;
	}
	public void setModelo(String modelo) {
		Modelo = modelo;
	}
	public String getSerie() {
		return Serie;
	}
	public void setSerie(String serie) {
		Serie = serie;
	}
	public String getMemoriaRAM() {
		return RAM;
	}
	public void setMemoriaRAM(String rAM) {
		RAM = rAM;
	}
	public String getProcesador() {
		return Procesador;
	}
	public void setProcesador(String procesador) {
		Procesador = procesador;
	}
	public String getDD_Serie() {
		return DD_Serie;
	}
	public void setDD_Serie(String dD_Serie) {
		DD_Serie = dD_Serie;
	}
	public String getDD_Tipo() {
		return DD_Tipo;
	}
	public void setDD_Tipo(String dD_Tipo) {
		DD_Tipo = dD_Tipo;
	}
	public String getDD_Capacidad() {
		return DD_Capacidad;
	}
	public void setDD_Capacidad(String dD_Capacidad) {
		DD_Capacidad = dD_Capacidad;
	}
	public String getCargador_Serie() {
		return Cargador_Serie;
	}
	public void setCargador_Serie(String cargador_Serie) {
		Cargador_Serie = cargador_Serie;
	}
	public String getSO() {
		return SO;
	}
	public void setSO(String sO) {
		SO = sO;
	}
	public String getOffice() {
		return Office;
	}
	public void setOffice(String office) {
		Office = office;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getFoto() {
		return Foto;
	}
	public void setFoto(String foto) {
		Foto = foto;
	}
	public String getObservaciones() {
		return Observaciones;
	}
	public void setObservaciones(String observaciones) {
		Observaciones = observaciones;
	}
	public String getEstatus() {
		return Estatus;
	}
	public void setEstatus(String estatus) {
		Estatus = estatus;
	}
	@Override
	public String toString() {
		return "EquipoComputo [EquipoComputo_id=" + EquipoComputo_id + ", Tipo=" + Tipo + ", Fch_Alta=" + Fch_Alta
				+ ", Marca=" + Marca + ", Modelo=" + Modelo + ", Serie=" + Serie + ", RAM=" + RAM + ", Procesador="
				+ Procesador + ", DD_Serie=" + DD_Serie + ", DD_Tipo=" + DD_Tipo + ", DD_Capacidad=" + DD_Capacidad
				+ ", Cargador_Serie=" + Cargador_Serie + ", SO=" + SO + ", Office=" + Office + ", Nombre=" + Nombre
				+ ", Foto=" + Foto + ", Observaciones=" + Observaciones + ", Estatus=" + Estatus + "]";
	}
	
	
	
}
