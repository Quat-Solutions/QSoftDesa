package net.vvivia.softwareQSNew.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.vvivia.softwareQSNew.Model.Empleado;




public interface EmpleadoRepository extends JpaRepository<Empleado, Integer> {
	
	@Query("Select e from Empleado e, Persona ep where e.Estatus <> 'INACTIVO' and ep.Nombre like %?1% order by ep.Nombre")
	Page<Empleado> busquedaListaEmpl(Pageable page, String Nombre);

}
