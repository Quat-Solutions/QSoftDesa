package net.vvivia.softwareQSNew.Service.db;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import net.vvivia.softwareQSNew.Model.Varios;
import net.vvivia.softwareQSNew.Repository.VariosRepository;
import net.vvivia.softwareQSNew.Service.IVariosService;
//Nayeli Meza
@Service
@Primary
public class VariosServiceJpa implements IVariosService {
	
	@Autowired
	private VariosRepository variosRepo;
	

	@Override
	public Page<Varios> buscarTodoPageable(Pageable page) {
		// TODO Auto-generated method stub
		return variosRepo.findAll(page);
	}

	@Override
	public List<Varios> buscarTodo() {
		// TODO Auto-generated method stub
		return variosRepo.findAll();
	}

	@Override
	public void guardar(Varios varios) {
		// TODO Auto-generated method stub
		variosRepo.save(varios);
		
	}

	@Override
	public List<Varios> buscarTodoIndex() {
		// TODO Auto-generated method stub
		return variosRepo.findAll();
	}

	@Override
	public Varios buscarPorId(Integer Varios_id) {
		// TODO Auto-generated method stub
		Optional<Varios>optional = variosRepo.findById(Varios_id);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public List<Varios> buscarByExample(Example<Varios> example) {
		// TODO Auto-generated method stub
		return variosRepo.findAll(example);
	}

	@Override
	public List<Varios> buscarTipo(Example<String> example) {
		
		return variosRepo.buscarVarios();
	}

	@Override
	public Page<Varios> buscarPorFiltro(Pageable page, String Tipo) {
		// TODO Auto-generated method stub
		return variosRepo.buscarFiltroListaVarios(page, Tipo);
	}
	
	//SERVICIO EQUIPOS DE COMPUTO
		@Override
		public List<Varios> buscarEquipoComputo() {
			return variosRepo.buscarEqComp();
		}
		@Override
		public List<Varios> buscarMarcas() {
			return variosRepo.buscarMarcas();
		}

		@Override
		public List<Varios> buscarRam() {
			return variosRepo.buscarMemoriaRam();
		}

		@Override
		public List<Varios> buscarProcesador() {
			return variosRepo.buscarNombreProcesador();
		}

		@Override
		public List<Varios> buscarSistemaOperativo() {
			return variosRepo.buscarSo();
		}

		@Override
		public List<Varios> buscarOffice() {
			return variosRepo.buscarLicenciaOffice();
		}

		@Override
		public List<Varios> buscarTipoDD() {
			return variosRepo.buscarTipoDiscoDuro();
		}

		@Override
		public List<Varios> buscarCapDD() {
			return variosRepo.buscarCapDiscoDuro();
		}

	

}
