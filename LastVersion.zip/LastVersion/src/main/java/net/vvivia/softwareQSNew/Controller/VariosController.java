package net.vvivia.softwareQSNew.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import net.vvivia.softwareQSNew.Model.SolicitudPersonal;
import net.vvivia.softwareQSNew.Model.Varios;
import net.vvivia.softwareQSNew.Repository.VariosRepository;
import net.vvivia.softwareQSNew.Service.IVariosService;
//Nayeli Meza
@Controller
@RequestMapping("/varios")
public class VariosController {
	
	@Autowired
	private IVariosService variosService;
	@Autowired
	private VariosRepository variosRepo;
	
	
//	@Value("${softwareQS.ruta.imagenes}")
//	private String ruta;

	@GetMapping("/utilerias")
	public String menuUtilerias(Model model) {	
		return "homeUtilerias";
	}
	
	@GetMapping("/index")
	public String mostrarIndexVarios(Model model) {
		System.out.println("Entro a /varios/Index: " );
		List<Varios> lista= variosRepo.buscarVarios();
		
		model.addAttribute("varios", lista);
		System.out.println(model);
		
		return "varios/listaVarios";
	}
	
	@GetMapping(value="/indexPaginate")
	public String mostrarIndexPaginado(Model model, Pageable page) {
		System.out.println("Entro a /varios/IndexPagination: " +page);
//		Page<Varios> lista = variosRepo.buscarTodoPageable(page);
		Varios varFiltro = new Varios();
		varFiltro.setTipo("");
		Page<Varios> lista = variosService.buscarPorFiltro(page, "");
				
		model.addAttribute("varios", lista);
		model.addAttribute("varFiltro", varFiltro);
		System.out.println("Salgo de /varios/IndexPaginate Lista Varios: " + lista);
		return "varios/listaVarios";
	}
	
	@GetMapping(value = "/create")
	public String crear(Model model) {
		System.out.println("Entrando a Crear Varios");
		Varios varios = new Varios();
		model.addAttribute("varios", varios);
		return "varios/formVarios";
	}
	
	@GetMapping("/edit/{id}")
	public String  editar(@PathVariable("id") int Varios_id, Model model) {
		System.out.println("Entradno a Editar Varios" + Varios_id);
		Varios varios = variosService.buscarPorId(Varios_id);
		System.out.println("ID de Varios" + varios.getVarios_id());
		model.addAttribute("varios", varios);
		
		System.out.println("Salgo d editar Varios"+ varios);
		
		return "varios/formVarios";
	}
	@PostMapping("/save")
	public String guardar(Varios varios,BindingResult result, RedirectAttributes attributes) {
		if(result.hasErrors()) {
			for(ObjectError error : result.getAllErrors()) {
				System.out.println("Ocurrio un Error "+ error.getDefaultMessage());
			}
			return "varios/formVarios";
		}
		varios.setEstatus("ACTIVO");
		System.out.println("Antes de Guardar Catalogo Varios " + varios);
		variosService.guardar(varios);
		attributes.addFlashAttribute("msg", "Registro Guardado");
		System.out.println("Varios Guardado Correctamente...!");	
		return "redirect:/varios/indexPaginate";
	}

	
	@GetMapping("/delete/{id}")
	public String eliminar(@PathVariable("id") int Varios_id, RedirectAttributes attributes) {
		System.out.println("Borrando equipo de computo con id: " + Varios_id);
		Varios varios = variosService.buscarPorId(Varios_id);
		varios.setEstatus("INACTIVO");
		variosService.guardar(varios);
		attributes.addFlashAttribute("msg","El registro del catalogo Varios fue eliminado!");
		return "redirect:/varios/indexPaginate";
	}
	
//	@GetMapping("/search")
//	public String buscar(@ModelAttribute("search")Varios varios,Model model,Pageable page) {
//		System.out.println("Buscando por vacante" + varios);
//		Example<Varios> example = Example.of(varios);
//		List<Varios>lista=  variosService.buscarByExample(example);
//		model.addAttribute("varios", lista);
//		return "varios/listaBusquedaVarios";
//	}
	
	@ModelAttribute
	public void setGenerico(Model model) {
		System.out.println("SetGenerico");
		Varios variosSearch = new Varios();
		
		System.out.println("SetGenerico"+ variosRepo.buscarVariosTipo());
		model.addAttribute("search", variosSearch);
		model.addAttribute("variosLista", variosRepo.buscarVariosTipo());
	}
	
	
	@GetMapping("/buscaFiltro")
	public String buscaPorFiltro(Model model, Pageable page, Varios variosFiltro) {
		System.out.println("Entro a /Varios/buscaPorFiltro: " + variosFiltro.getTipo());
		String  Tipo= variosFiltro.getTipo();
	
		Page<Varios> lista = variosService.buscarPorFiltro(page, Tipo);
		model.addAttribute("varios", lista);
		model.addAttribute("varFiltro", variosFiltro);
		System.out.println("Salgo de /varios/buscaPorFiltro Lista varios: " + variosFiltro.getTipo());
		return "varios/listaVarios";
	}
}
