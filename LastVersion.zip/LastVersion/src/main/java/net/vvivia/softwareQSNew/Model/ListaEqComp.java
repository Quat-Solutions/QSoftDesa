package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Subselect;

@Entity
@Subselect("select equipocomputo_id, tipo, fch_alta, marca, modelo, serie, ram, procesador, dd_serie, dd_tipo, dd_capacidad, cargador_serie, so, office, nombre, foto, observaciones, estatus from equipo_computo where estatus <> 'INACTIVO' order by equipocomputo_id")
public class ListaEqComp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer EquipoComputo_id;
	private String Tipo;
	private String Fch_Alta;
	private String Marca;
	private String Modelo;
	private String Serie;
	private String Nombre;
	private String Observaciones;
	
	public Integer getEquipoComputo_id() {
		return EquipoComputo_id;
	}
	public void setEquipoComputo_id(Integer equipoComputo_id) {
		EquipoComputo_id = equipoComputo_id;
	}
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	public String getFch_Alta() {
		return Fch_Alta;
	}
	public void setFch_Alta(String fch_Alta) {
		Fch_Alta = fch_Alta;
	}
	public String getMarca() {
		return Marca;
	}
	public void setMarca(String marca) {
		Marca = marca;
	}
	public String getModelo() {
		return Modelo;
	}
	public void setModelo(String modelo) {
		Modelo = modelo;
	}
	public String getSerie() {
		return Serie;
	}
	public void setSerie(String serie) {
		Serie = serie;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getObservaciones() {
		return Observaciones;
	}
	public void setObservaciones(String observaciones) {
		Observaciones = observaciones;
	}
	@Override
	public String toString() {
		return "ListaEqComp [EquipoComputo_id=" + EquipoComputo_id + ", Tipo=" + Tipo + ", Fch_Alta=" + Fch_Alta
				+ ", Marca=" + Marca + ", Modelo=" + Modelo + ", Serie=" + Serie + ", Nombre=" + Nombre
				+ ", Observaciones=" + Observaciones + "]";
	}
	
}
