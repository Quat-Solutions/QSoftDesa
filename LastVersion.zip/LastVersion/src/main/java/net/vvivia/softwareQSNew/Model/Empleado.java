package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "empleado")
public class Empleado {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Empleado_id;
	//private Integer Persona_id;
	private Integer Empresa_id;
	//private Integer Domicilio_id;
	private String  Fecha_inicio;
	private String  Estatus;

	@ManyToOne
	@JoinColumn(name = "persona_id")
	private Persona Empleado_Persona;
	
	@ManyToOne
	@JoinColumn(name = "domicilio_id")
	private Domicilio Empleado_Domicilio;

	public Integer getEmpleado_id() {
		return Empleado_id;
	}

	public void setEmpleado_id(Integer empleado_id) {
		Empleado_id = empleado_id;
	}

	public Integer getEmpresa_id() {
		return Empresa_id;
	}

	public void setEmpresa_id(Integer empresa_id) {
		Empresa_id = empresa_id;
	}

	public String getFecha_inicio() {
		return Fecha_inicio;
	}

	public void setFecha_inicio(String fecha_inicio) {
		Fecha_inicio = fecha_inicio;
	}

	public String getEstatus() {
		return Estatus;
	}

	public void setEstatus(String estatus) {
		Estatus = estatus;
	}

	public Persona getEmpleado_Persona() {
		return Empleado_Persona;
	}

	public void setEmpleado_Persona(Persona empleado_Persona) {
		Empleado_Persona = empleado_Persona;
	}

	public Domicilio getEmpleado_Domicilio() {
		return Empleado_Domicilio;
	}

	public void setEmpleado_Domicilio(Domicilio empleado_Domicilio) {
		Empleado_Domicilio = empleado_Domicilio;
	}

	@Override
	public String toString() {
		return "Empleado [Empleado_id=" + Empleado_id + ", Empresa_id=" + Empresa_id + ", Fecha_inicio=" + Fecha_inicio
				+ ", Estatus=" + Estatus + ", Empleado_Persona=" + Empleado_Persona + ", Empleado_Domicilio="
				+ Empleado_Domicilio + "]";
	}

	


}
