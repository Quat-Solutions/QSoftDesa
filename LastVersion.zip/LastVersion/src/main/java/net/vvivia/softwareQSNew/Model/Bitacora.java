package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bitacora")
public class Bitacora {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Bitacora_id;
	private String UserName;
	private String Pantalla;
	private String TipoAccion;
	private Integer Idregistro;
	private String Fecha;
	private String Estatus;

	public Integer getBitacora_id() {
		return Bitacora_id;
	}

	public void setBitacora_id(Integer bitacora_id) {
		Bitacora_id = bitacora_id;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPantalla() {
		return Pantalla;
	}

	public void setPantalla(String pantalla) {
		Pantalla = pantalla;
	}

	public String getTipoAccion() {
		return TipoAccion;
	}

	public void setTipoAccion(String tipoAccion) {
		TipoAccion = tipoAccion;
	}

	public Integer getIdregistro() {
		return Idregistro;
	}

	public void setIdregistro(Integer idregistro) {
		Idregistro = idregistro;
	}

	public String getEstatus() {
		return Estatus;
	}

	public void setEstatus(String estatus) {
		Estatus = estatus;
	}

	public String getFecha() {
		return Fecha;
	}

	public void setFecha(String fecha) {
		Fecha = fecha;
	}

	@Override
	public String toString() {
		return "Bitacora [Bitacora_id=" + Bitacora_id + ", UserName=" + UserName + ", Pantalla=" + Pantalla
				+ ", TipoAccion=" + TipoAccion + ", Idregistro=" + Idregistro + ", Fecha=" + Fecha + ", Estatus="
				+ Estatus + "]";
	}

}
