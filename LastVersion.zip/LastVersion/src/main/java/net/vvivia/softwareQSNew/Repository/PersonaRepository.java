package net.vvivia.softwareQSNew.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.vvivia.softwareQSNew.Model.Persona;

public interface PersonaRepository extends JpaRepository<Persona, Integer> {
	
	List<Persona> findBy();

}
