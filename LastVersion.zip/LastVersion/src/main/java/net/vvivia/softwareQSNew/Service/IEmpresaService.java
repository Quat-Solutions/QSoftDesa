package net.vvivia.softwareQSNew.Service;

import java.util.List;
import net.vvivia.softwareQSNew.Model.EmpresaCatalogo;

public interface IEmpresaService {

	List<EmpresaCatalogo> buscarTodo();
	
}
