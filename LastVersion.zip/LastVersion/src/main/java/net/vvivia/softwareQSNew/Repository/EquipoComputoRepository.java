package net.vvivia.softwareQSNew.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.vvivia.softwareQSNew.Model.EquipoComputo;

public interface EquipoComputoRepository extends JpaRepository<EquipoComputo, Integer> {

	@Query("Select eq from EquipoComputo eq where Estatus <> 'INACTIVO' ")
	Page<EquipoComputo> buscaListaEqComp(Pageable page, String Marca, String Modelo, String Estatus);
	
	@Query("Select eq from EquipoComputo eq where Estatus <> 'INACTIVO' and Marca like ?1% and Modelo like ?2% and Estatus like ?3% ")
	Page<EquipoComputo> buscaFiltroListaEqComp(Pageable page, String marca, String modelo, String estatus);
	
	@Query("Select eq from EquipoComputo eq where Estatus <> 'INACTIVO'")
	Page<EquipoComputo> buscarPageable(Pageable page);
	
	@Query("Select eq from EquipoComputo eq where Estatus <> 'INACTIVO'")
	List<EquipoComputo> buscarTodoLista();
	
	@Query("Select DISTINCT eq.Modelo from EquipoComputo eq where eq.Estatus <> 'INACTIVO'")
	List<String>buscarModelosRepo();
	
	@Query("Select DISTINCT eq.Estatus from EquipoComputo eq where eq.Estatus <> 'INACTIVO'")
	List<String>buscarEstatusRepo();
	
	@Query("Select DISTINCT eq.Marca from EquipoComputo eq where eq.Estatus <> 'INACTIVO'")
	List<String>buscarMarcaEqRepo(); 
	
}

	//and Marca = ?1 or Modelo = ?2 or Estatus = ?3 