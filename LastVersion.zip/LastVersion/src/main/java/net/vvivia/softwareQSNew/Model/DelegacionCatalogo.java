package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Subselect;

@Entity
@Subselect("Select varios_id, descripcion from varios where estatus <> 'INACTIVO' and Tipo = 'ALCALDIA/MUNICIPIO' order by descripcion")
public class DelegacionCatalogo {

	@Id
	private Integer Varios_id;
	private String Descripcion;

	public Integer getVarios_id() {
		return Varios_id;
	}

	public void setVarios_id(Integer varios_id) {
		Varios_id = varios_id;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "EstadosCatalogo [Varios_id=" + Varios_id + ", Descripcion=" + Descripcion + "]";
	}

}
