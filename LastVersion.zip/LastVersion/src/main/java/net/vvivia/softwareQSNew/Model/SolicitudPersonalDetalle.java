package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="solicitud_personal_detalle")
public class SolicitudPersonalDetalle {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Solicitud_personal_detalle_id;
	private String Tipo;
	private Integer Solicitud_persona_id;
	private String Nombre;
	private String Descripcion;
	private String Estatus;
	
	
	public Integer getSolicitud_personal_detalle_id() {
		return Solicitud_personal_detalle_id;
	}
	public void setSolicitud_personal_detalle_id(Integer solicitud_personal_detalle_id) {
		Solicitud_personal_detalle_id = solicitud_personal_detalle_id;
	}
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	public Integer getSolicitud_persona_id() {
		return Solicitud_persona_id;
	}
	public void setSolicitud_persona_id(Integer solicitud_persona_id) {
		Solicitud_persona_id = solicitud_persona_id;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}
	public String getEstatus() {
		return Estatus;
	}
	public void setEstatus(String estatus) {
		Estatus = estatus;
	}
	@Override
	public String toString() {
		return "SolicitudPersonalDetalle [Solicitud_personal_detalle_id=" + Solicitud_personal_detalle_id + ", Tipo="
				+ Tipo + ", Solicitud_persona_id=" + Solicitud_persona_id + ", Nombre=" + Nombre + ", Descripcion="
				+ Descripcion + ", Estatus=" + Estatus + "]";
	}
	
	
	
	
	
	
	
}
