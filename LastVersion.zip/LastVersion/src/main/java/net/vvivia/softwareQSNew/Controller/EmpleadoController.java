package net.vvivia.softwareQSNew.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import net.vvivia.softwareQSNew.Model.Documento;
import net.vvivia.softwareQSNew.Model.Empleado;
import net.vvivia.softwareQSNew.Model.EmpleadoPersona;
import net.vvivia.softwareQSNew.Service.IBitacoraService;
import net.vvivia.softwareQSNew.Service.ICatalogoVariosService;
import net.vvivia.softwareQSNew.Service.IEmpleadoService;
import net.vvivia.softwareQSNew.Service.IEmpresaService;
import net.vvivia.softwareQSNew.Util.Utileria;


@Controller
@RequestMapping(value="/empleado")
public class EmpleadoController {

	
	@Value("${softwareQS.ruta.imagenes}")
	private String ruta;
	
	@Autowired
	private IEmpleadoService empleadoService;
	
	@Autowired
	private IEmpresaService empresaService;
	
	@Autowired
	private ICatalogoVariosService catVariosService;
	
	@Autowired
	private IBitacoraService bitService;


	@GetMapping(value = "/rrhh")
	public String menuRRHH(Model model, Pageable page) {
		return "homeRRHH";
	}
	
	
	@GetMapping(value = "/indexPaginate")
	public String mostrarIndexPaginado(Model model, Pageable page) {
		EmpleadoPersona empleadoFiltro = new EmpleadoPersona();
		empleadoFiltro.setNombre("");
		empleadoFiltro.setAp_Paterno("");
		empleadoFiltro.setAp_Materno("");
		Page<EmpleadoPersona> lista = empleadoService.buscarPorFiltro(page, "","","");
		model.addAttribute("empleados", lista);
		model.addAttribute("empFiltro", empleadoFiltro);
		return "empleados/listEmpleados";
	}

	
	@GetMapping("/buscaFiltro")
	public String buscaPorFiltro(Model model, Pageable page, EmpleadoPersona empFiltro) {
		String Nombre = empFiltro.getNombre();
		String ApPaterno = empFiltro.getAp_Paterno();
		String ApMaterno = empFiltro.getAp_Materno();
		Page<EmpleadoPersona> lista = empleadoService.buscarPorFiltro(page, Nombre, ApPaterno, ApMaterno);
		model.addAttribute("empleados", lista);
		model.addAttribute("empFiltro", empFiltro);
		return "empleados/listEmpleados";
	}

	
	@GetMapping("/docs/{id}")
	public String documentacionEmp(@PathVariable("id") int Empleado_id, Model model, Pageable page) {
		Documento docEmpleado = new Documento();	
		Empleado empleado = empleadoService.buscarPorId(Empleado_id);	
		model.addAttribute("empleado", empleado);
		List<Documento> empDocs = empleadoService.buscarEmpDocumentos(empleado.getEmpleado_id());
		model.addAttribute("empleadoDocs",empDocs);
		docEmpleado.setEmpleado_id(empleado.getEmpleado_id());
		model.addAttribute("empleadoDoc",docEmpleado);
		model.addAttribute("tipoDocs", catVariosService.buscarTipoDoc());
		
		return "empleados/listEmpleadosDocs";
	}
	
	
	@PostMapping("/save")
	public String guardar(Empleado empleado, Authentication aut, BindingResult result, 
			RedirectAttributes attributes,  @RequestParam("archivoImagen") MultipartFile multiPart) {
			
		String tipoAccion = "";
		
		if (result.hasErrors()) {
			for (ObjectError error: result.getAllErrors()){
				System.out.println("Ocurrio un error: "+ error.getDefaultMessage());
			}			
			return "empleados/formEmpleado";
		}
		
		if (!multiPart.isEmpty()) {
			String nombreImagen = Utileria.guardarArchivo(multiPart, ruta);
			if (nombreImagen != null){ // La imagen si se subio
				// Procesamos la variable nombreImagen
				empleado.getEmpleado_Persona().setFoto(nombreImagen);
			}
		}
		
		if (empleado.getEmpleado_id() == null  ) {
			tipoAccion="ALTA";
		} else {
			tipoAccion="EDITADO";
		}
		
		//Guardo Empleado
		empleado.setEstatus("ACTIVO");
		empleado.getEmpleado_Persona().setTipo("FISICA");
		empleado.getEmpleado_Persona().setEstatus("ACTIVO");
		empleado.getEmpleado_Domicilio().setTipo("EMPLEADO/PARTICULAR");
		empleado.getEmpleado_Domicilio().setEstatus("ACTIVO");
		
		empleadoService.guardar(empleado);
		
		//Registro en Bitacora
		bitService.guardar(aut.getName(), "EMPLEADO", tipoAccion, empleado.getEmpleado_id());

		attributes.addFlashAttribute("msg", "Registro Guardado");		
				
		return "redirect:/empleado/indexPaginate"; 
	}
	
	
	@PostMapping("/saveDoc")
	public String guardarDoc(Documento empleadoDoc, Authentication aut, BindingResult result, RedirectAttributes attributes, 
			@RequestParam("archivoImagen") MultipartFile multiPart) {
		
		if (result.hasErrors()) {
			for (ObjectError error: result.getAllErrors()){
				System.out.println("Ocurrio un error: "+ error.getDefaultMessage());
			}			
			return "empleados/listEmpleadosDocs";
		}
		
		if (!multiPart.isEmpty()) {
			String nombreImagen = Utileria.guardarArchivo(multiPart, ruta);
			if (nombreImagen != null){ // La imagen si se subio
				// Procesamos la variable nombreImagen
				empleadoDoc.setArchivo(nombreImagen);
			}
		}
		
		empleadoDoc.setEstatus("ACTIVO");
		//Guardo Documento
		empleadoService.guardarEmpDoc(empleadoDoc);
		
		//Registro en Bitacora
		bitService.guardar(aut.getName(), "EMPLEADO DOCUMENTO", "SUBIR DOCUMENTO", empleadoDoc.getDocumento_id());
		
		attributes.addFlashAttribute("msg", "Documento Guardado");		

		return "redirect:/empleado/docs/" + empleadoDoc.getEmpleado_id(); 
		
	}	

	
	@GetMapping("/delete/{id}")
	public String eliminar(@PathVariable("id") int Empleado_id, Authentication aut, RedirectAttributes attributes) {
		
		Empleado empleado = empleadoService.buscarPorId(Empleado_id);
		empleado.setEstatus("INACTIVO");
		//Baja Logica Empleado
		empleadoService.guardar(empleado);
		
		//Registro en Bitacora
		bitService.guardar(aut.getName(), "EMPLEADO", "BAJA LOGICA", empleado.getEmpleado_id());
		
		attributes.addFlashAttribute("msg","El registro del empleado fue eliminado!");
		return "redirect:/empleado/indexPaginate";
	}

	
	@GetMapping("/deleteDoc/{id}")
	public String eliminaEmpDoc(@PathVariable("id") int Documento_id, Authentication aut, RedirectAttributes attributes) {
		
		Documento Documento = empleadoService.buscarEmpDocPorId(Documento_id);
		Documento.setEstatus("INACTIVO");
		//Baja Logica Documento
		empleadoService.guardarEmpDoc(Documento);
		
		//Registro en Bitacora
		bitService.guardar(aut.getName(), "EMPLEADO DOCUMENTO", "BAJA LOGICA DOCUMENTO", Documento.getDocumento_id());
			
		attributes.addFlashAttribute("msg","El documento del empleado fue eliminado!");
		return "redirect:/empleado/docs/" + Documento.getEmpleado_id();
	}
	
	
	@GetMapping("/edit/{id}")
	public String editar(@PathVariable("id") int Empleado_id, Model model)  {
		
		Empleado empleado = empleadoService.buscarPorId(Empleado_id);
		model.addAttribute("empresas",empresaService.buscarTodo());
		model.addAttribute("estadosMex",catVariosService.buscarTodo());
		model.addAttribute("delegaciones",catVariosService.buscarDelegacion());	
		model.addAttribute("empleado", empleado);
		
		return "empleados/formEmpleado";
	}
	
	
	@GetMapping("/create")
	public String crear(EmpleadoPersona empleadoPersona, Model model) {
		System.out.println("Entro a Alta Empleado... ");
		Empleado empleadoSave = new Empleado();
		String userName="";
		if(empleadoPersona.getEmpleado_id() != null) {
			System.out.println("Entre IF: " + empleadoPersona.getEmpleado_id());
			empleadoSave = empleadoService.buscarPorId(empleadoPersona.getEmpleado_id());
		}	
		
		model.addAttribute("empleado", empleadoSave);
		model.addAttribute("userName", userName);
		model.addAttribute("empresas",empresaService.buscarTodo());
		model.addAttribute("estadosMex",catVariosService.buscarTodo());
		model.addAttribute("delegaciones",catVariosService.buscarDelegacion());
		System.out.println("salgo empleado/create: " + model.getAttribute("delegaciones"));
		return "empleados/formEmpleado";
	}
	
}
