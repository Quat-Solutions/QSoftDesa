package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="solicitud_personal")
public class SolicitudPersonal {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Solicitud_personal_id;
	private String Area_cliente;
	private Integer Usuario_id;
	private Integer Empresa_id;
	private String Fch_solicitud;
	private String Fch_inicio;
	private String Nombre;
	private String Motivo;
	private String Otro_motivo;
	private String Funciones;
	private String Tipo_contrato;
	private String Otro_tipo;
	private String Tiempo;
	private double Ingreso_sugerido;
	private double Tarifa_sugerida;
	private String Otros_beneficios;
	private String Nivel_educativo;
	private String Experiencia_minima;
	private String Estatus;
	
	
	public Integer getSolicitud_personal() {
		return Solicitud_personal_id;
	}
	public void setSolicitud_personal(Integer solicitud_personal) {
		Solicitud_personal_id = solicitud_personal;
	}
	public String getArea_cliente() {
		return Area_cliente;
	}
	public void setArea_cliente(String area_cliente) {
		Area_cliente = area_cliente;
	}
	public Integer getUsuario_id() {
		return Usuario_id;
	}
	public void setUsuario_id(Integer usuario_id) {
		Usuario_id = usuario_id;
	}
	public Integer getEmpresa_id() {
		return Empresa_id;
	}
	public void setEmpresa_id(Integer empresa_id) {
		Empresa_id = empresa_id;
	}
	public String getFch_solicitud() {
		return Fch_solicitud;
	}
	public void setFch_solicitud(String fch_solicitud) {
		Fch_solicitud = fch_solicitud;
	}
	public String getFch_inicio() {
		return Fch_inicio;
	}
	public void setFch_inicio(String fch_inicio) {
		Fch_inicio = fch_inicio;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getMotivo() {
		return Motivo;
	}
	public void setMotivo(String motivo) {
		Motivo = motivo;
	}
	public String getOtro_motivo() {
		return Otro_motivo;
	}
	public void setOtro_motivo(String otro_motivo) {
		Otro_motivo = otro_motivo;
	}
	public String getFunciones() {
		return Funciones;
	}
	public void setFunciones(String funciones) {
		Funciones = funciones;
	}
	public String getTipo_contrato() {
		return Tipo_contrato;
	}
	public void setTipo_contrato(String tipo_contrato) {
		Tipo_contrato = tipo_contrato;
	}
	public String getOtro_tipo() {
		return Otro_tipo;
	}
	public void setOtro_tipo(String otro_tipo) {
		Otro_tipo = otro_tipo;
	}
	public String getTiempo() {
		return Tiempo;
	}
	public void setTiempo(String tiempo) {
		Tiempo = tiempo;
	}
	public double getIngreso_sugerido() {
		return Ingreso_sugerido;
	}
	public void setIngreso_sugerido(double ingreso_sugerido) {
		Ingreso_sugerido = ingreso_sugerido;
	}
	public double getTarifa_sugerida() {
		return Tarifa_sugerida;
	}
	public void setTarifa_sugerida(double tarifa_sugerida) {
		Tarifa_sugerida = tarifa_sugerida;
	}
	public String getOtros_beneficios() {
		return Otros_beneficios;
	}
	public void setOtros_beneficios(String otros_beneficios) {
		Otros_beneficios = otros_beneficios;
	}
	public String getNivel_educativo() {
		return Nivel_educativo;
	}
	public void setNivel_educativo(String nivel_educativo) {
		Nivel_educativo = nivel_educativo;
	}
	public String getExperiencia_minima() {
		return Experiencia_minima;
	}
	public void setExperiencia_minima(String experiencia_minima) {
		Experiencia_minima = experiencia_minima;
	}
	public String getEstatus() {
		return Estatus;
	}
	public void setEstatus(String estatus) {
		Estatus = estatus;
	}
	@Override
	public String toString() {
		return "SolicitudPersonalModel [Solicitud_personal=" + Solicitud_personal_id + ", Area_cliente=" + Area_cliente
				+ ", Usuario_id=" + Usuario_id + ", Empresa_id=" + Empresa_id + ", Fch_solicitud=" + Fch_solicitud
				+ ", Fch_inicio=" + Fch_inicio + ", Nombre=" + Nombre + ", Motivo=" + Motivo + ", Otro_motivo="
				+ Otro_motivo + ", Funciones=" + Funciones + ", Tipo_contrato=" + Tipo_contrato + ", Otro_tipo="
				+ Otro_tipo + ", Tiempo=" + Tiempo + ", Ingreso_sugerido=" + Ingreso_sugerido + ", Tarifa_sugerida="
				+ Tarifa_sugerida + ", Otros_beneficios=" + Otros_beneficios + ", Nivel_educativo=" + Nivel_educativo
				+ ", Experiencia_minima=" + Experiencia_minima + ", Estatus=" + Estatus + "]";
	}
	
	
	
}
