package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.Id;


import org.hibernate.annotations.Subselect;

@Entity
@Subselect("select e.empleado_id, p.nombre, p.ap_paterno, p.ap_materno, e.fecha_inicio from empleado e, persona p where e.estatus <> 'INACTIVO' and p.persona_id = e.persona_id order by p.nombre")
public class EmpleadoPersona {

	@Id
	private Integer Empleado_id;
	private String  Nombre;
	private String  Ap_Paterno;
	private String  Ap_Materno;
	private String  Fecha_inicio;
	public Integer getEmpleado_id() {
		return Empleado_id;
	}
	public void setEmpleado_id(Integer empleado_id) {
		Empleado_id = empleado_id;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getAp_Paterno() {
		return Ap_Paterno;
	}
	public void setAp_Paterno(String ap_Paterno) {
		Ap_Paterno = ap_Paterno;
	}
	public String getAp_Materno() {
		return Ap_Materno;
	}
	public void setAp_Materno(String ap_Materno) {
		Ap_Materno = ap_Materno;
	}
	public String getFecha_inicio() {
		return Fecha_inicio;
	}
	public void setFecha_inicio(String fecha_inicio) {
		Fecha_inicio = fecha_inicio;
	}
	@Override
	public String toString() {
		return "EmpleadoPersona [Empleado_id=" + Empleado_id + ", Nombre=" + Nombre + ", Ap_Paterno=" + Ap_Paterno
				+ ", Ap_Materno=" + Ap_Materno + ", Fecha_inicio=" + Fecha_inicio + "]";
	}

	
	
}
