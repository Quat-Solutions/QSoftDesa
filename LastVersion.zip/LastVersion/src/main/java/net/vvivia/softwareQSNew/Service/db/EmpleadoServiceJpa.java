package net.vvivia.softwareQSNew.Service.db;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import net.vvivia.softwareQSNew.Model.Documento;
import net.vvivia.softwareQSNew.Model.Empleado;
import net.vvivia.softwareQSNew.Model.EmpleadoPersona;
import net.vvivia.softwareQSNew.Repository.DocumentoRepository;
import net.vvivia.softwareQSNew.Repository.DomicilioRepository;
import net.vvivia.softwareQSNew.Repository.EmpleadoPersonaRepository;
import net.vvivia.softwareQSNew.Repository.EmpleadoRepository;
import net.vvivia.softwareQSNew.Repository.PersonaRepository;
import net.vvivia.softwareQSNew.Service.IEmpleadoService;

@Service
@Primary
public class EmpleadoServiceJpa implements IEmpleadoService{

	@Autowired
	private EmpleadoRepository empleadoRepo;
	
	@Autowired
	private PersonaRepository empPerRepo;
	
	@Autowired
	private DomicilioRepository empDomRepo;
	
	@Autowired
	private DocumentoRepository empDocRepo;
	
	@Autowired
	private EmpleadoPersonaRepository empleadoPersonaRepo;
	
	public List<Empleado> buscarTodo() {
		return empleadoRepo.findAll();
	}

	@Override
	public Page<Empleado> buscarTodo(Pageable page) {
		System.out.println("Entro al servicio Empleado buscarTodo Paginas: " + empleadoRepo.findAll(page).getTotalPages());
		return empleadoRepo.findAll(page);

	}

	@Override
	public Page<EmpleadoPersona> buscarTodoEmp(Pageable page) {
		System.out.println("Entro al servicio EmpleadoPersona buscarTodo Paginas: " + empleadoRepo.findAll(page).getTotalPages());
		//return empleadoRepo.findAll(page);
		return empleadoPersonaRepo.findAll(page);
	}
	
	
	
	
	@Override
	public Empleado buscarPorId(Integer Empleado_id) {
		Optional<Empleado> optional = empleadoRepo.findById(Empleado_id);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public void guardar(Empleado empleado) {
	
		empPerRepo.save(empleado.getEmpleado_Persona());
		empDomRepo.save(empleado.getEmpleado_Domicilio());
		empleadoRepo.save(empleado);
	}

	
	public List<Documento> buscarEmpDocumentos(Integer empleado_id) {
		return empDocRepo.buscaDocsEmp(empleado_id);
	}

	@Override
	public void guardarEmpDoc(Documento Doc) {
		empDocRepo.save(Doc);
		System.out.println("Guardo Documento" + Doc);
	}

	@Override
	public Documento buscarEmpDocPorId(Integer Documento_id) {
		Optional<Documento> optional = empDocRepo.findById(Documento_id);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public Page<EmpleadoPersona> buscarPorFiltro(Pageable page, String Nombre, String ApPaterno, String ApMaterno) {
		return empleadoPersonaRepo.buscaFiltroListaEmp(page, Nombre, ApPaterno, ApMaterno);
	}
	


}
