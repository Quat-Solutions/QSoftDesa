package net.vvivia.softwareQSNew.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import net.vvivia.softwareQSNew.Model.Documento;
import net.vvivia.softwareQSNew.Model.Empleado;
import net.vvivia.softwareQSNew.Model.SolicitudPersonal;
import net.vvivia.softwareQSNew.Model.SolicitudPersonalDetalle;
import net.vvivia.softwareQSNew.Repository.SolicitudPersonalRepository;
import net.vvivia.softwareQSNew.Repository.VariosRepository;
import net.vvivia.softwareQSNew.Service.ISolicitudesPersonalService;
import net.vvivia.softwareQSNew.Util.Utileria;

@Controller
@RequestMapping(value="/solicitud")
public class SolicitudController {
	
	@Autowired
	private VariosRepository variosRepoCat;
	@Autowired
	private SolicitudPersonalRepository solicitudRepo;
	
	@Autowired
	private ISolicitudesPersonalService solPersService;

	
//	@Autowired
//	private ISolicitudesPersonalService solicitudServie;
	
	@GetMapping(value="/index")
	public String menuSolicitud(Model model) {
		System.out.println("Entrando index solicitudes");
		List<SolicitudPersonal> lista = solicitudRepo.buscarSolicitud();
		model.addAttribute("solicitudes",lista);
		System.out.println("Resultado model " + model);

		return"solicitudes/listaSolicitudes";
		
	}
	
	@GetMapping(value="/indexPaginate")
	public String menuSolicitudPaginado(Model model,Pageable page) {
		System.out.println("Entrando index solicitudes");
//		Page<SolicitudPersonal> lista = solicitudRepo.buscarSolicitudPageable(page);
		SolicitudPersonal solFiltro= new SolicitudPersonal();
		solFiltro.setNombre("");
		solFiltro.setArea_cliente("");
		solFiltro.setEstatus("");
//	
//			Page<SolicitudPersonal> lista = solicitudRepo.buscarSolicitudPageable(page);
//			model.addAttribute("solicitudes",lista);
		
			Page<SolicitudPersonal> lista1 = solPersService.buscarPorFiltro(page, "", "", "");
			model.addAttribute("solicitudes",lista1);
			model.addAttribute("solFiltro",solFiltro);
			System.out.println("Resultado model " + model);
	
		

		return"solicitudes/listaSolicitudes";
		
	}
	
	
	@PostMapping("/save")
	public String guardar(SolicitudPersonal solicitudPersonal,BindingResult result, RedirectAttributes attributes) {
		if(result.hasErrors()) {
			for(ObjectError error : result.getAllErrors()) {
				System.out.println("Ocurrio un Error "+ error.getDefaultMessage());
			}
			return "solicitudes/formSolicitudes";
		}
		solicitudPersonal.setEstatus("ACTIVO");
		solicitudPersonal.setUsuario_id(1);
		solicitudPersonal.setEmpresa_id(1);
		System.out.println("Antes de Guardar Catalogo Varios " + solicitudPersonal);
		solPersService.guardar(solicitudPersonal);
		attributes.addFlashAttribute("msg", "Registro Guardado");
		System.out.println("Solicitud Guardada Correctamente...!");	
		return "redirect:/solicitud/indexPaginate";
	}
	
	@GetMapping(value = "/edit/{id}")
	public String editar(@PathVariable("id") int Solicitud_personal_id, Model model) {
		System.out.println("Entrando a editar solicitud ");
		SolicitudPersonal solicitud = solPersService.buscarPorId(Solicitud_personal_id);
		
		System.out.println("Id de Solicitud " + solicitud.getSolicitud_personal());
		model.addAttribute("areas",variosRepoCat.busquedaTiposeArea());
		model.addAttribute("motivos", variosRepoCat.busquedaTiposMotivo());
		model.addAttribute("tiposContratos", variosRepoCat.busquedaTipoContrato());
		model.addAttribute("tiposEducativos", variosRepoCat.busquedaTipoEducativo());
		model.addAttribute("tiposCompetencias", variosRepoCat.busquedaTipoCompetencias());
		model.addAttribute("solicitudes", solicitud);
		System.out.println("Saliendo editar Solicitud");
		return "solicitudes/formSolicitudes";
	}
	@GetMapping(value="/create")
	public String crear(SolicitudPersonal solPerso,Model model) {
		System.out.println("Entrando a crear solicitud");
		SolicitudPersonal solicitudPersonal = new SolicitudPersonal();
		if(solPerso.getSolicitud_personal()!= null) {
			System.out.println("Entre IF " +solPerso.getSolicitud_personal());
			solicitudPersonal= solPersService.buscarPorId(solPerso.getSolicitud_personal());
			
		}
		
		
		model.addAttribute("areas",variosRepoCat.busquedaTiposeArea());
		model.addAttribute("motivos", variosRepoCat.busquedaTiposMotivo());
		model.addAttribute("tiposContratos", variosRepoCat.busquedaTipoContrato());
		model.addAttribute("tiposEducativos", variosRepoCat.busquedaTipoEducativo());
		model.addAttribute("tiposCompetencias", variosRepoCat.busquedaTipoCompetencias());
		model.addAttribute("solicitudes", solicitudPersonal);
		return"solicitudes/formSolicitudes";
		
	}
	@GetMapping("/delete/{id}")
	public String eliminar(@PathVariable("id") int Solicitud_personal_id, RedirectAttributes attributes) {
		System.out.println("Borrando Solicitud con id: " + Solicitud_personal_id);
		SolicitudPersonal solicitud = solPersService.buscarPorId(Solicitud_personal_id);
		solicitud.setEstatus("INACTIVO");
		solPersService.guardar(solicitud);
		attributes.addFlashAttribute("msg","El registro de la Solicitud fue eliminado!");
		return "redirect:/solicitud/indexPaginate";
	}
	
	@GetMapping("/buscaFiltro")
	public String buscaPorFiltro(Model model, Pageable page, SolicitudPersonal solFiltro) {
		System.out.println("Entro a /empleado/buscaPorFiltro: " + solFiltro.getNombre());
		String  Nombre= solFiltro.getNombre();
		String Area_cliente = solFiltro.getArea_cliente();
		String Estatus = solFiltro.getEstatus();
		Page<SolicitudPersonal> lista = solPersService.buscarPorFiltro(page, Nombre, Area_cliente, Estatus);
		model.addAttribute("solicitudes", lista);
		model.addAttribute("solFiltro", solFiltro);
		System.out.println("Salgo de /empleado/buscaPorFiltro Lista empleados: " + solFiltro.getNombre());
		return "solicitudes/listaSolicitudes";
	}
	
	@GetMapping("/solicitudDetalle/{id}")
	public String detalleSolicitud(@PathVariable("id") int Solicitud_persona_id, Model model, Pageable page) {
		System.out.println("Entro a detalles solicitud... " + Solicitud_persona_id);
		SolicitudPersonalDetalle personalDetalle = new SolicitudPersonalDetalle();	
		SolicitudPersonal solicitudPersonal = solPersService.buscarPorId(Solicitud_persona_id);	
		model.addAttribute("solicitud", solicitudPersonal);
		List<SolicitudPersonalDetalle> detSoli = solPersService.buscarSolicitudDetalle(solicitudPersonal.getSolicitud_personal());
		model.addAttribute("detalleSol",detSoli);
		personalDetalle.setSolicitud_persona_id(solicitudPersonal.getSolicitud_personal());
		model.addAttribute("personalDetalle",personalDetalle);
		model.addAttribute("tiposCompetencias",variosRepoCat.busquedaTipoCompetencias() );
		System.out.println("Salgo de Docs Empleado... " + personalDetalle.getSolicitud_persona_id());
		
		return "solicitudes/listaSolicitudesDetalle";
	}
	
	
	
	
	@PostMapping("/saveDetalle")
	public String guardarDetalles(SolicitudPersonalDetalle soliciDetalle, BindingResult result, RedirectAttributes attributes) {
		
		System.out.println("Entro a SaveDetalles ");
		if (result.hasErrors()) {
			for (ObjectError error: result.getAllErrors()){
				System.out.println("Ocurrio un error: "+ error.getDefaultMessage());
			}			
			return "solicitudes/listaSolicitudesDetalle";
		}
		
		
//		soliciDetalle.setSolicitud_persona_id(soliciDetalle.getSolicitud_persona_id());
//		soliciDetalle.setSolicitud_persona_id(1);
		soliciDetalle.setEstatus("ACTIVO");
		System.out.println("Antes de guardar solicitud Detalle : " + soliciDetalle);
		solPersService.guardarDetalleSol(soliciDetalle);
		attributes.addFlashAttribute("msg", "Detalles Guardado");		
		System.out.println("SolicitudDetalle hasta aqui llegue");
		return "redirect:/solicitud/solicitudDetalle/" + soliciDetalle.getSolicitud_persona_id();
		
	}	
	@GetMapping("/deleteSoliDetalle/{id}")
	public String eliminaSolicitudDetalle(@PathVariable("id") int Solicitud_personal_detalle_id, RedirectAttributes attributes) {
		System.out.println("Borrando documento con id: " + Solicitud_personal_detalle_id);
		SolicitudPersonalDetalle personalDetalle= solPersService.buscarSolicitusDetallePorId(Solicitud_personal_detalle_id);
		personalDetalle.setEstatus("INACTIVO");
		solPersService.guardarDetalleSol(personalDetalle);
		attributes.addFlashAttribute("msg","La solicitud Detalle fue eliminado!");
		return "redirect:/solicitud/solicitudDetalle/" + personalDetalle.getSolicitud_personal_detalle_id();
	}

	
}
