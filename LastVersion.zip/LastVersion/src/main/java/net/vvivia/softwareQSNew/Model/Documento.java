package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "documento")
public class Documento {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Documento_id;
	private Integer Empleado_id;
	private String TipoDoc;
	private String Descripcion;
	private String Archivo;
	private String Estatus;

	public Integer getDocumento_id() {
		return Documento_id;
	}

	public void setDocumento_id(Integer documento_id) {
		Documento_id = documento_id;
	}

	public Integer getEmpleado_id() {
		return Empleado_id;
	}

	public void setEmpleado_id(Integer empleado_id) {
		Empleado_id = empleado_id;
	}

	public String getTipoDoc() {
		return TipoDoc;
	}

	public void setTipoDoc(String tipoDoc) {
		TipoDoc = tipoDoc;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	public String getArchivo() {
		return Archivo;
	}

	public void setArchivo(String archivo) {
		Archivo = archivo;
	}

	public String getEstatus() {
		return Estatus;
	}

	public void setEstatus(String estatus) {
		Estatus = estatus;
	}

	@Override
	public String toString() {
		return "Documento [Documento_id=" + Documento_id + ", Empleado_id=" + Empleado_id + ", TipoDoc=" + TipoDoc
				+ ", Descripcion=" + Descripcion + ", Archivo=" + Archivo + ", Estatus=" + Estatus + "]";
	}

}
