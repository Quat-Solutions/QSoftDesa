package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Subselect;

@Entity
//@Subselect("select * from varios")
@Subselect("select varios_id, tipo,descripcion, observaciones, numero , estatus from varios where tipo ='1' and estatus='ACTIVO'")
public class ListaVarios {
	//Nayeli Meza
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Varios_id;
	private Integer Tipo;
	private String Descripcion;
	private String Observaciones;
	private Integer Numero;
	private String Estatus;
	public Integer getVarios_id() {
		return Varios_id;
	}
	public void setVarios_id(Integer varios_id) {
		Varios_id = varios_id;
	}
	public Integer getTipo() {
		return Tipo;
	}
	public void setTipo(Integer tipo) {
		Tipo = tipo;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}
	public String getObservaciones() {
		return Observaciones;
	}
	public void setObservaciones(String observaciones) {
		Observaciones = observaciones;
	}
	public Integer getNumero() {
		return Numero;
	}
	public void setNumero(Integer numero) {
		Numero = numero;
	}
	public String getEstatus() {
		return Estatus;
	}
	public void setEstatus(String estatus) {
		Estatus = estatus;
	}
	@Override
	public String toString() {
		return "ListaVarios [Varios_id=" + Varios_id + ", Tipo=" + Tipo + ", Descripcion=" + Descripcion
				+ ", Observaciones=" + Observaciones + ", Numero=" + Numero + ", Estatus=" + Estatus + "]";
	}
	
	

}
