package net.vvivia.softwareQSNew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftwareQsNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoftwareQsNewApplication.class, args);
	}

}
