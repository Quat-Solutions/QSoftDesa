package net.vvivia.softwareQSNew.Service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import net.vvivia.softwareQSNew.Model.EquipoComputo;


public interface IEquipoComputoService {

	Page<EquipoComputo> buscarTodoPageable(Pageable page);
	void guardar(EquipoComputo equipoComputo);
	EquipoComputo buscarPorId(Integer EquipoComputo_id);
	Page<EquipoComputo> buscarTodoPageable(Pageable page, String Marca, String Modelo, String Estatus);
	Page<EquipoComputo> buscarTodoFiltro(Pageable page, String marca, String modelo, String estatus);
	List<EquipoComputo> buscarTodo();
	List<String> buscarModelos();
	List<String> buscarEstatus();
	List<String> buscarMarcasEq();
}
