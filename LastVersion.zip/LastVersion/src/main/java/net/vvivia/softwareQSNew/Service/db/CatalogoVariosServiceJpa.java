package net.vvivia.softwareQSNew.Service.db;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import net.vvivia.softwareQSNew.Model.DelegacionCatalogo;
import net.vvivia.softwareQSNew.Model.EstadosCatalogo;
import net.vvivia.softwareQSNew.Model.TipoDocCatalogo;
import net.vvivia.softwareQSNew.Repository.DelegacionCatalogoRepository;
import net.vvivia.softwareQSNew.Repository.EstadosCatalogoRepository;
import net.vvivia.softwareQSNew.Repository.TipoDocRepository;
import net.vvivia.softwareQSNew.Service.ICatalogoVariosService;

@Service
@Primary
public class CatalogoVariosServiceJpa implements ICatalogoVariosService {
	
	@Autowired
	EstadosCatalogoRepository edoCatRepo;

	@Autowired
	DelegacionCatalogoRepository delCatRepo;
	
	@Autowired
	TipoDocRepository tipoDocRepo;
	
	@Override
	public List<EstadosCatalogo> buscarTodo() {
		return edoCatRepo.findAll(); 
	}

	@Override
	public List<DelegacionCatalogo> buscarDelegacion() {
		return delCatRepo.findAll();
	}

	@Override
	public List<TipoDocCatalogo> buscarTipoDoc() {
		return tipoDocRepo.findAll();
	}

}
