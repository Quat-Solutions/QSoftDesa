package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "persona")
//@Subselect("select * from persona order by nombre")
public class Persona {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Persona_id;
	private String Nombre;
	private String Ap_Paterno;
	private String Ap_Materno;
	private String Fch_Nacimiento;
	private String Sexo;
	private String RFC;
	private String Foto;
	private String Celular;
	private String Email;
	private String Tipo;
	private String Nacionalidad;
	private String Estatus;



	public Integer getPersona_id() {
		return Persona_id;
	}

	public void setPersona_id(Integer persona_id) {
		Persona_id = persona_id;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getAp_Paterno() {
		return Ap_Paterno;
	}

	public void setAp_Paterno(String ap_Paterno) {
		Ap_Paterno = ap_Paterno;
	}

	public String getAp_Materno() {
		return Ap_Materno;
	}

	public void setAp_Materno(String ap_Materno) {
		Ap_Materno = ap_Materno;
	}

	public String getFch_Nacimiento() {
		return Fch_Nacimiento;
	}

	public void setFch_Nacimiento(String fch_Nacimiento) {
		Fch_Nacimiento = fch_Nacimiento;
	}

	public String getSexo() {
		return Sexo;
	}

	public void setSexo(String sexo) {
		Sexo = sexo;
	}

	public String getRFC() {
		return RFC;
	}

	public void setRFC(String rFC) {
		RFC = rFC;
	}

	public String getFoto() {
		return Foto;
	}

	public void setFoto(String foto) {
		Foto = foto;
	}

	public String getCelular() {
		return Celular;
	}

	public void setCelular(String celular) {
		Celular = celular;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getNacionalidad() {
		return Nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		Nacionalidad = nacionalidad;
	}

	public String getEstatus() {
		return Estatus;
	}

	public void setEstatus(String estatus) {
		Estatus = estatus;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	@Override
	public String toString() {
		return "Persona [Persona_id=" + Persona_id + ", Nombre=" + Nombre + ", Ap_Paterno=" + Ap_Paterno
				+ ", Ap_Materno=" + Ap_Materno + ", Fch_Nacimiento=" + Fch_Nacimiento + ", Sexo=" + Sexo + ", RFC="
				+ RFC + ", Foto=" + Foto + ", Celular=" + Celular + ", Email=" + Email + ", Tipo=" + Tipo
				+ ", Nacionalidad=" + Nacionalidad + ", Estatus=" + Estatus + "]";
	}


	

}
