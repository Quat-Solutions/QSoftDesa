package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "domicilio")
public class Domicilio {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Domicilio_id;
	private String Calle;
	private String Numero;
	private String Colonia;
	private String CP;
	private Integer Estado_mex_id;
	private Integer Delegacion_id;
	private String Tipo;
	private String Tel;
	private String Estatus;

	public Integer getDomicilio_id() {
		return Domicilio_id;
	}

	public void setDomicilio_id(Integer domicilio_id) {
		Domicilio_id = domicilio_id;
	}

	public String getCalle() {
		return Calle;
	}

	public void setCalle(String calle) {
		Calle = calle;
	}

	public String getNumero() {
		return Numero;
	}

	public void setNumero(String numero) {
		Numero = numero;
	}

	public String getColonia() {
		return Colonia;
	}

	public void setColonia(String colonia) {
		Colonia = colonia;
	}

	public String getCP() {
		return CP;
	}

	public void setCP(String cP) {
		CP = cP;
	}

	public Integer getEstado_mex_id() {
		return Estado_mex_id;
	}

	public void setEstado_mex_id(Integer estado_mex_id) {
		Estado_mex_id = estado_mex_id;
	}

	public Integer getDelegacion_id() {
		return Delegacion_id;
	}

	public void setDelegacion_id(Integer delegacion_id) {
		Delegacion_id = delegacion_id;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getTel() {
		return Tel;
	}

	public void setTel(String tel) {
		Tel = tel;
	}

	public String getEstatus() {
		return Estatus;
	}

	public void setEstatus(String estatus) {
		Estatus = estatus;
	}

	@Override
	public String toString() {
		return "Domicilio [Domicilio_id=" + Domicilio_id + ", Calle=" + Calle + ", Numero=" + Numero + ", Colonia="
				+ Colonia + ", CP=" + CP + ", Estado_mex_id=" + Estado_mex_id + ", Delegacion_id=" + Delegacion_id
				+ ", Tipo=" + Tipo + ", Tel=" + Tel + ", Estatus=" + Estatus + "]";
	}


}
