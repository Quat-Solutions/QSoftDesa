package net.vvivia.softwareQSNew.Service.db;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import net.vvivia.softwareQSNew.Model.Bitacora;
import net.vvivia.softwareQSNew.Repository.BitacoraRepository;
import net.vvivia.softwareQSNew.Service.IBitacoraService;

@Service
@Primary
public class BitacoraServiceJpa implements IBitacoraService {

	@Autowired
	private BitacoraRepository bitRepo;
	
	Date objDate = new Date();
	
	@Override
	public void guardar(String userName, String Pantalla, String tipoAccion, Integer idRegistro) {
		Bitacora bitacora = new Bitacora();
		
		bitacora.setUserName(userName);
		bitacora.setPantalla(Pantalla);
		bitacora.setTipoAccion(tipoAccion);
		bitacora.setIdregistro(idRegistro);
		bitacora.setFecha(objDate.toString());
		bitacora.setEstatus("REGISTRADO");
		
		bitRepo.save(bitacora);
	}

}
