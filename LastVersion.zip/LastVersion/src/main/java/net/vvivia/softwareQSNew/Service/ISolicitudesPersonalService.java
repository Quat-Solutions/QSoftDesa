package net.vvivia.softwareQSNew.Service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import net.vvivia.softwareQSNew.Model.SolicitudPersonal;
import net.vvivia.softwareQSNew.Model.SolicitudPersonalDetalle;

public interface ISolicitudesPersonalService {
	
	List<SolicitudPersonal> buscarTodosActivos();
	SolicitudPersonal buscarPorId(Integer Solicitud_personal_id);
	void guardar(SolicitudPersonal solicitudPersonal);
	Page<SolicitudPersonal> buscarPorFiltro(Pageable page, String Nombre,String Area_cliente, String Estatus);
	List<SolicitudPersonalDetalle>buscarSolicitudDetalle(Integer Solicitud_personal_id);
	SolicitudPersonalDetalle buscarSolicitusDetallePorId(Integer Solicitud_personal_detalle_id);
	void guardarDetalleSol(SolicitudPersonalDetalle sol);
	

}
