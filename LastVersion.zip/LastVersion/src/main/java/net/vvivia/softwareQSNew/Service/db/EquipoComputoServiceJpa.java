package net.vvivia.softwareQSNew.Service.db;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import net.vvivia.softwareQSNew.Model.EquipoComputo;
import net.vvivia.softwareQSNew.Repository.EquipoComputoRepository;
import net.vvivia.softwareQSNew.Service.IEquipoComputoService;

@Service
@Primary
public class EquipoComputoServiceJpa implements IEquipoComputoService {

	@Autowired
	private EquipoComputoRepository equipoCompRepo;
	
	@Override
	public Page<EquipoComputo> buscarTodoPageable(Pageable page) {
		System.out.println("Entro al servicio EquipoComputo buscarTodo Paginas: " + equipoCompRepo.findAll(page).getTotalPages());
		return equipoCompRepo.buscarPageable(page);
	}

	@Override
	public List<EquipoComputo> buscarTodo() {
		return equipoCompRepo.buscarTodoLista();
	}

	@Override
	public void guardar(EquipoComputo equipoComputo) {
		equipoCompRepo.save(equipoComputo);
	}

	@Override
	public EquipoComputo buscarPorId(Integer EquipoComputo_id) {
		Optional<EquipoComputo> optional = equipoCompRepo.findById(EquipoComputo_id);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	public Page<EquipoComputo> buscarTodoPageable(Pageable page, String Marca, String Modelo, String Estatus) {
		return equipoCompRepo.buscaListaEqComp(page, Marca, Modelo, Estatus);
	}

	@Override
	public List<String> buscarMarcasEq() {
		return equipoCompRepo.buscarMarcaEqRepo();
	}

	@Override
	public List<String> buscarModelos() {
		return equipoCompRepo.buscarModelosRepo();
	}

	@Override
	public List<String> buscarEstatus() {
		return equipoCompRepo.buscarEstatusRepo();
	}

	@Override
	public Page<EquipoComputo> buscarTodoFiltro(Pageable page, String marca, String modelo, String estatus) {
		return equipoCompRepo.buscaFiltroListaEqComp(page, marca, modelo, estatus);
	}
	
}
