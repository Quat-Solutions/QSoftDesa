package net.vvivia.softwareQSNew.Service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import net.vvivia.softwareQSNew.Model.Documento;
import net.vvivia.softwareQSNew.Model.Empleado;
import net.vvivia.softwareQSNew.Model.EmpleadoPersona;




public interface IEmpleadoService {

	List<Empleado> buscarTodo();
	Page<Empleado> buscarTodo(Pageable page);
	Page<EmpleadoPersona> buscarTodoEmp(Pageable page);
	Empleado buscarPorId(Integer Empleado_id);
	
	void guardar(Empleado empleado);
	
	List<Documento> buscarEmpDocumentos(Integer empleado_id);
	Documento buscarEmpDocPorId(Integer Documento_id);
	
	void guardarEmpDoc(Documento Doc);
	
	Page<EmpleadoPersona> buscarPorFiltro(Pageable page, String Nombre, String ApPaterno, String ApMaterno);
	
}
