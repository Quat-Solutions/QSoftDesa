package net.vvivia.softwareQSNew.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.vvivia.softwareQSNew.Model.SolicitudPersonal;

public interface SolicitudPersonalRepository extends JpaRepository<SolicitudPersonal, Integer>{
	
	@Query("Select s from SolicitudPersonal  s where Estatus='ACTIVO'")
	List<SolicitudPersonal>buscarSolicitud();
	
	@Query("Select s from SolicitudPersonal  s where Estatus='ACTIVO'")
	Page<SolicitudPersonal>buscarSolicitudPageable(Pageable page);
	
	@Query("Select ep from SolicitudPersonal ep where Nombre like ?1% and Area_cliente like ?2% and Estatus like ?3%")
	Page<SolicitudPersonal> buscaFiltroListaSolicitud(Pageable page,String Nombre, String Area_cliente,String Estatus);

}
