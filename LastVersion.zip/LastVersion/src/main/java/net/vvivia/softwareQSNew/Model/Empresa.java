package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "empresa")
public class Empresa {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Empresa_id;
	private Integer Persona_id;
	private String Representante;
	private String Tel1;
	private String Tel2;
	private String Tipo;
	private String Estatus;


	@ManyToOne
	@JoinColumn(name = "persona_id")
	private Persona Empresa_Persona;

	public Integer getEmpresa_id() {
		return Empresa_id;
	}

	public void setEmpresa_id(Integer empresa_id) {
		Empresa_id = empresa_id;
	}

	public Integer getPersona_id() {
		return Persona_id;
	}

	public void setPersona_id(Integer persona_id) {
		Persona_id = persona_id;
	}

	public String getRepresentante() {
		return Representante;
	}

	public void setRepresentante(String representante) {
		Representante = representante;
	}

	public String getTel1() {
		return Tel1;
	}

	public void setTel1(String tel1) {
		Tel1 = tel1;
	}

	public String getTel2() {
		return Tel2;
	}

	public void setTel2(String tel2) {
		Tel2 = tel2;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getEstatus() {
		return Estatus;
	}

	public void setEstatus(String estatus) {
		Estatus = estatus;
	}

	public Persona getEmpresa_Persona() {
		return Empresa_Persona;
	}

	public void setEmpresa_Persona(Persona persona) {
		Empresa_Persona = persona;
	}

	@Override
	public String toString() {
		return "Empresa [Empresa_id=" + Empresa_id + ", Persona_id=" + Persona_id + ", Representante=" + Representante
				+ ", Tel1=" + Tel1 + ", Tel2=" + Tel2 + ", Tipo=" + Tipo + ", Estatus=" + Estatus + ", Persona="
				+ Empresa_Persona + "]";
	}


}
