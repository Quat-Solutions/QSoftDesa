package net.vvivia.softwareQSNew.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.vvivia.softwareQSNew.Model.Documento;

public interface DocumentoRepository extends JpaRepository<Documento, Integer> {

	@Query("from Documento d where d.Empleado_id = ?1 and Estatus ='ACTIVO'")
	List<Documento> buscaDocsEmp(Integer Empleado_id);
	
	
}
