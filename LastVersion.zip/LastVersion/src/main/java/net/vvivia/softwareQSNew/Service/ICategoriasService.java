package net.vvivia.softwareQSNew.Service;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import net.vvivia.softwareQSNew.Model.Categoria;

public interface ICategoriasService {
	void guardar(Categoria categoria);
	List<Categoria> buscarTodas();
	Categoria buscarPorId(Integer idCategoria);		
	void eliminar(Integer idCategoria);
	Page<Categoria> buscarTodas(Pageable page);	
}