package net.vvivia.softwareQSNew.Service.db;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import net.vvivia.softwareQSNew.Model.EmpresaCatalogo;
import net.vvivia.softwareQSNew.Repository.EmpresaCatalogoRepository;
import net.vvivia.softwareQSNew.Service.IEmpresaService;

@Service
@Primary
public class EmpresaServiceJpa implements IEmpresaService {

	
	@Autowired
	EmpresaCatalogoRepository empCatRepo;

	@Override
	public List<EmpresaCatalogo> buscarTodo() {
		return empCatRepo.findAll();
	}
	
	
	
}
