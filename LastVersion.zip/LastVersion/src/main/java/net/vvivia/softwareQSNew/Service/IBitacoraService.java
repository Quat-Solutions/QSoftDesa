package net.vvivia.softwareQSNew.Service;


public interface IBitacoraService {
	
	void guardar(String userName, String Pantalla, String tipoAccion, Integer idRegistro);

}
