package net.vvivia.softwareQSNew.Service;

import java.util.List;

import net.vvivia.softwareQSNew.Model.DelegacionCatalogo;
import net.vvivia.softwareQSNew.Model.EstadosCatalogo;
import net.vvivia.softwareQSNew.Model.TipoDocCatalogo;

public interface ICatalogoVariosService {

	List<EstadosCatalogo> buscarTodo();
	List<DelegacionCatalogo> buscarDelegacion();
	List<TipoDocCatalogo> buscarTipoDoc();
}
