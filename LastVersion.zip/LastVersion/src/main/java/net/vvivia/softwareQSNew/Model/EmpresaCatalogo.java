package net.vvivia.softwareQSNew.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Subselect;

@Entity
@Subselect("Select e.empresa_id, p.nombre from empresa e, persona p where e.estatus = 'ACTIVO' and p.persona_id = e.persona_id order by p.nombre")
public class EmpresaCatalogo {

	@Id
	private Integer Empresa_id;
	private String  Nombre;
	
	
	public Integer getEmpresa_id() {
		return Empresa_id;
	}
	public void setEmpresa_id(Integer empresa_id) {
		Empresa_id = empresa_id;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	@Override
	public String toString() {
		return "EmpresaCatalogo [Empresa_id=" + Empresa_id + ", Nombre=" + Nombre + "]";
	}
	
	
	
}
