package net.vvivia.softwareQSNew.Service;

import java.util.List;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import net.vvivia.softwareQSNew.Model.Varios;
//Nayeli Meza
public interface IVariosService {

	
	Page<Varios> buscarTodoPageable(Pageable page);
	List<Varios> buscarTodo ();
	void guardar(Varios varios);
	List<Varios> buscarTodoIndex ();
	Varios buscarPorId(Integer Varios_id);
	List<Varios>buscarByExample(Example<Varios> example);
	List<Varios>buscarTipo(Example<String> example);
	Page<Varios>buscarPorFiltro(Pageable page, String Tipo);
	//SERVICIO EQUIPOS DE COMPUTO
	List<Varios>buscarEquipoComputo();
	List<Varios>buscarMarcas();
	List<Varios>buscarRam();
	List<Varios>buscarProcesador();
	List<Varios>buscarTipoDD();
	List<Varios>buscarCapDD();
	List<Varios>buscarSistemaOperativo();
	List<Varios>buscarOffice();
}
