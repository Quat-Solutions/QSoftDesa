package net.vvivia.softwareQSNew.Service.db;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import net.vvivia.softwareQSNew.Model.SolicitudPersonal;
import net.vvivia.softwareQSNew.Model.SolicitudPersonalDetalle;
import net.vvivia.softwareQSNew.Repository.SolicitudPersonalDetalleRepository;
import net.vvivia.softwareQSNew.Repository.SolicitudPersonalRepository;
import net.vvivia.softwareQSNew.Service.ISolicitudesPersonalService;
@Service
@Primary
public class SolicitudPersonalServiceJpa implements ISolicitudesPersonalService {
	
	@Autowired
	private SolicitudPersonalRepository solicitudRepo;
	@Autowired
	private SolicitudPersonalDetalleRepository detaleRepo;
	

	@Override
	public List<SolicitudPersonal> buscarTodosActivos() {
		// TODO Auto-generated method stub
		return solicitudRepo.findAll();
	}


	@Override
	public SolicitudPersonal buscarPorId(Integer Solicitud_personal_id) {
		// TODO Auto-generated method stub
		Optional<SolicitudPersonal>optional = solicitudRepo.findById(Solicitud_personal_id);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}


	@Override
	public void guardar(SolicitudPersonal solicitudPersonal) {
		// TODO Auto-generated method stub
		solicitudRepo.save(solicitudPersonal);
		
	}


	@Override
	public Page<SolicitudPersonal> buscarPorFiltro(Pageable page, String Nombre, String Area_cliente, String Estatus) {
		
		
		return solicitudRepo.buscaFiltroListaSolicitud(page, Nombre, Area_cliente, Estatus);
	}


	@Override
	public List<SolicitudPersonalDetalle> buscarSolicitudDetalle(Integer Solicitud_personal_id) {
		// TODO Auto-generated method stub
		return detaleRepo.buscaSolcitudDetalle(Solicitud_personal_id);
	}


	@Override
	public void guardarDetalleSol(SolicitudPersonalDetalle sol) {
		// TODO Auto-generated method stub
		detaleRepo.save(sol);
		System.out.println("Detalle " + detaleRepo);
		
	}


	@Override
	public SolicitudPersonalDetalle buscarSolicitusDetallePorId(Integer Solicitud_personal_detalle_id) {
		// TODO Auto-generated method stub
		Optional<SolicitudPersonalDetalle> optional= detaleRepo.findById(Solicitud_personal_detalle_id);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

}
