package net.vvivia.softwareQSNew.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.vvivia.softwareQSNew.Model.Varios;
//import net.vvivia.softwareQSNew.Model.VariosMarca;

public interface VariosRepository extends JpaRepository<Varios, Integer> {
	
	@Query("select v from Varios v where Estatus= 'ACTIVO'")
	List<Varios> buscarVarios();
	@Query("select v from Varios v where Estatus= 'ACTIVO'")
	Page<Varios> buscarTodoPageable(Pageable page);
	
//	@Query("select DISTINCT v.Tipo from Varios v where Estatus='ACTIVO'")
//	List<String> buscarVariosTipo();
	@Query("select DISTINCT v.Tipo from Varios v where Estatus='ACTIVO'")
	List<String> buscarVariosTipo();
	
	@Query("select  v from Varios v where Tipo=?1 and Estatus='ACTIVO'")
	List<Varios> busquedaTipos(String tipo);
	
	@Query("select v from Varios  v where estatus='ACTIVO' and Tipo='AREA'")
	List<Varios> busquedaTiposeArea();
	
	@Query("select v from Varios  v where estatus='ACTIVO' and Tipo='MOTIVO'")
	List<Varios> busquedaTiposMotivo();
	
	@Query("select v from Varios  v where estatus='ACTIVO' and Tipo='TIPOCONTRATO'")
	List<Varios> busquedaTipoContrato();
	
	@Query("select v from Varios  v where estatus='ACTIVO' and Tipo='NIVELEDUCATIVO'")
	List<Varios> busquedaTipoEducativo();
	
	@Query("select v from Varios v WHERE v.Tipo In('COMPETENCIA', 'HERRAMIENTA')")
	List<Varios> busquedaTipoCompetencias();
	
	@Query("select v from Varios v where v.Tipo like ?1% and v.Estatus= 'ACTIVO'")
	Page<Varios> buscarFiltroListaVarios(Pageable page,String Tipo);
	
	//CONSULTAS EQUIPOCOMPUTO
		@Query("select v from Varios v where Tipo='EQUIPOCOMPUTO'")
		List<Varios> buscarEqComp();
		
		@Query("select v from Varios v where Tipo='MARCA'")
		List<Varios> buscarMarcas();
		
		@Query("select v from Varios v where Tipo='MEMORIA RAM'")
		List<Varios> buscarMemoriaRam();
		
		@Query("select v from Varios v where Tipo='PROCESADOR'")
		List<Varios> buscarNombreProcesador();
		
		@Query("select v from Varios v where Tipo='TIPODISCODURO'")
		List<Varios> buscarTipoDiscoDuro();
		
		@Query("select v from Varios v where Tipo='CAPACIDADDISCODURO'")
		List<Varios> buscarCapDiscoDuro();
		
		@Query("select v from Varios v where Tipo='SISTEMAOPERATIVO'")
		List<Varios> buscarSo();
		
		@Query("select v from Varios v where Tipo='OFFICE'")
		List<Varios> buscarLicenciaOffice();
		/////////

}
