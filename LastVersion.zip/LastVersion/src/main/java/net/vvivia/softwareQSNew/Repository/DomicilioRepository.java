package net.vvivia.softwareQSNew.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.vvivia.softwareQSNew.Model.Domicilio;

public interface DomicilioRepository extends JpaRepository<Domicilio, Integer> {

}
