package net.vvivia.softwareQSNew.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.vvivia.softwareQSNew.Model.ListaEqComp;

public interface ListaEqCompRepository extends JpaRepository<ListaEqComp, Integer> {

}
